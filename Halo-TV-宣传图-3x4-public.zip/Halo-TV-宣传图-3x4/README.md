# Halo TV 3:4 宣传图（24 张）

每张图片为 1200 × 1600（3:4），JPG 高质量导出。所有页面均包含 Halo TV / Null 署名及“基于 Aerial 开源项目二次开发｜非官方修改版”声明。

## 素材说明

- 桌面与翻页时钟画面取自 Halo TV 1.58 发布资料中的 TCL Q10G Pro 截图；设置画面取自本地电视端截图。图中时间、天气和应用会随设备设置变化。
- ADB 教程中的电视画面作为真实设备展示底图；步骤文字来自本版本安装说明。品牌路径可能随固件和地区不同。
- 已实测设备：TCL Q10G Pro（MT5879 / Android 11）。其他 Android TV / Google TV 未逐台回归；Tizen、webOS、VIDAA 等非 Android TV 系统不适用。
- 视频壁纸、刷新率选项等是否可用，取决于电视硬件、解码能力和系统是否开放对应模式。
- 用户头像来自用户提供的头像图片；头像原图与 Halo TV 图标一并放入 assets。

## 文件

- `图片/`：24 张独立宣传图
- `总览拼图.jpg`：整套缩略图预览
- `assets/`：Halo TV 应用图标（头像原图未单独打包）

项目声明：Halo TV 基于 [pengchujin/aerial-tv](https://github.com/pengchujin/aerial-tv) 二次开发，非 Aerial 原作者发行版、非官方版本；上游 MIT 许可与版权声明保留在项目中。